require_relative 'spaceship'
 
    describe Spaceship do
    	it "warps to a destination" do
            spaceship = Spaceship.new("Canoe", 1)
            expect(spaceship.warp_to("Home")).to eq("Home")
        end

        it "prints the inventory" do
        	spaceship = Spaceship.new("Kayak", 2)
        	expect(spaceship.pickup("home", "keys")).to eq(true)
        	expect(spaceship.print_inventory).to eq([{:item=>"keys", :location=>"home"}])
        end
    end
