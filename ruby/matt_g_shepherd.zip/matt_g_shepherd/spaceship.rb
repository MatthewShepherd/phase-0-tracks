class Spaceship
	attr_reader :max_speed, :location, :inventory
	attr_accessor :name


    def initialize(name, speed)
    	@name = name
    	@max_speed = speed
    	@shield_on = true
    	@location = nil
    	@inventory = []  
    end

    def enable_shield
    	@shield_on = true
    end

    def disable_shield
    	@shield_on = false
    end

    def warp_to(destination)
    	p "Traveling at #{max_speed} to #{destination}!"
    	@location = destination
    end

    def tractor_beam(item)    	
    	disable_shield
    	weight = 0
    	item.split('').each do |i|    	  
    	  weight += i.ord
    	end
    	if weight >= 500
    		p "This #{item} is too heavy!"
    		enable_shield
    		false
    	end
    	acquired_item = {}    
        acquired_item[:item] = item
        acquired_item[:location] = @location
        @inventory << acquired_item
        p @inventory
        enable_shield
        true
    end

    def pickup(destination, item)
    	warp_to(destination)
    	tractor_beam(item)
    end

    def print_inventory
    	@inventory.each do |i|
            p "This #{i[:item]} was picked up at #{i[:location]}."
        end 
    end

    def total_weight
    	ttl_weight = 0
    	@inventory.each do |i|
            i[:item].split('').each do |j|
                ttl_weight += j.ord
            end
    	end
    	p ttl_weight
    end	

end
