class Farm
	attr_reader :area, :animals, :total_lbs
	attr_accessor :name

	def initialize(name, area)
		@name = name
		@area = area
		@animals = {}
		@total_lbs = 0
	end

	def open_door
		p "Barn door is open."
	end

	def close_door
		p "Barn door is closed."
	end

	def new_animal(species, food_int)
		if food_int + @total_lbs <= @area
		open_door
		@animals[species] = food_int
        close_door
        else
    	    p "The #{species} will have to find a new home."
    	end
    end

    def display_farm_animals
    	@animals.each do |animal, food|
    		p "The #{animal} requires #{food}lbs of food."
    	end
    end

    def total_food_needed
    	p @total_lbs = @animals.inject(0) { |lbs, food| lbs += food[1] }
    end
end

farm1 = Farm.new("farmville", 80)
farm2 = Farm.new("twelve oaks", 200)

p farm1
p farm2

farm1.name = "Farmville"
farm1.area
p farm1

farm2.open_door
farm2.close_door

farm1.new_animal("Goat", 5)
farm1.new_animal("Pig", 10)
p farm1
farm1.display_farm_animals
farm1.total_food_needed
p farm1
farm1.new_animal("SuperFatChicken", 400)