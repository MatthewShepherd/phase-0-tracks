require_relative 'farm'

describe Farm do
	it "adds a new species and food integer to a hash" do
		farm = Farm.new("animal", 400)
		expect(farm.new_animal("animal", 400).should eq("The animal will have to find a new home.")
	end
end

# Still working on writing rspec tests
# but submitting work before time expiration